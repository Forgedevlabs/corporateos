# INCIDENT_RESPONSE_POSTMORTEM_SOP.md
**Owner:** CTO + CSO (shared)  
**Enforced by:** CTO + CSO + Incident Commander (IC) + QA/Audit (where relevant)  
**Applies to:** Any outage, security event, or major degradation across the organization and its portfolio  
**Status:** Non-Negotiable (defines how we protect trust)

> **Authority split:** CTO leads technical containment and remediation. CSO leads investigation and postmortem. See `executives/CSO_CHARTER.md` §9 and `executives/CTO_CHARTER.md` §2.

---

## 0) Purpose
Incidents will happen. What matters is:
- how fast we contain
- how clearly we communicate
- how well we prevent recurrence

This SOP standardizes:
- severity levels
- roles + response flow
- communication
- postmortems and action tracking

---

## 1) What counts as an incident
An incident is any event that impacts:
- availability (downtime)
- correctness (wrong data, broken flows)
- security (leaks, unauthorized access, exposed secrets)
- performance (severe degradation)
- customer trust (payments failing, auth failing, data loss)

---

## 2) Severity Levels (SEV0–SEV3)

### SEV0 — Critical
- confirmed data breach or major compromise
- widespread outage or data loss risk
- payments/auth down at scale

### SEV1 — High
- major feature outage affecting many users
- repeated failures with no immediate workaround
- exposed secret/token (suspected or confirmed)

### SEV2 — Medium
- partial degradation
- limited-scope bug with workaround
- suspicious activity not confirmed

### SEV3 — Low
- minor issues, limited impact
- non-urgent policy violations

---

## 3) Roles (who does what)

### Incident Commander (IC)
- runs the incident
- assigns owners
- keeps the timeline
- decides escalation level
- ensures comms happen

### Tech Lead (TL) — reports to CTO
- leads technical diagnosis and mitigation
- coordinates engineers
- proposes rollback/patch plans

### CSO (or Security Lead)
- leads investigation and assessment (what was accessed, what data, what timeframe)
- determines if security incident requires escalation
- leads postmortem process
- owns policy/standards updates from incident learnings

### Comms Lead (CL)
- handles internal and (if needed) external communication
- keeps stakeholders updated (CEO/COO/support)

### Scribe
- logs timeline
- records decisions
- captures action items

### Approver (CTO)
- final approval on high-risk mitigation steps
- required for SEV0/SEV1 closure
- owns technical remediation action items

**Rule:** One person can hold multiple roles in small teams, but IC must be explicit.

---

## 4) Response Flow (standard)

### Step 1 — Declare
- assign severity
- appoint IC and TL
- **if security-related:** engage CSO immediately
- open incident log (timeline)

### Step 2 — Contain (CTO/TL lead)
Primary goal: stop the bleeding.
- rollback release if needed
- disable feature flag
- revoke/rotate secrets if security-related
- isolate integration if third-party is failing

### Step 3 — Diagnose (CSO leads assessment, TL leads technical diagnosis)
- identify failure mode
- confirm impact scope:
  - who is affected
  - what data is affected
  - when it started
- **CSO determines:** Was data accessed? What was exposed? What's the blast radius?

### Step 4 — Fix / Mitigate (CTO/TL lead)
- implement smallest safe fix
- validate in staging if possible (hotfix may be direct but still tested)
- deploy with monitoring

### Step 5 — Recover (CTO/TL lead)
- confirm system health
- confirm customer flows restored
- monitor for stability window
- **CSO verifies:** security posture restored

### Step 6 — Close (temporary)
- document current state
- schedule postmortem (required for SEV0/SEV1)

---

## 5) Communication Protocol

### 5.1 Internal updates (required)
- SEV0: every 15–30 minutes
- SEV1: every 30–60 minutes
- SEV2: every 2–4 hours (or as agreed)
- SEV3: as needed

Stakeholders:
- CEO/GM (customer impact)
- COO (ops impact)
- Support (customer comms)
- EIC (if public comms needed)

### 5.2 External comms (only when needed)
External comms must be:
- factual
- calm
- specific
- no speculation

Use:
- "We're investigating…"
- "Impact: …"
- "Mitigation: …"
- "Next update at: …"

Never:
- blame vendors publicly without proof
- promise a fix time unless confident

---

## 6) Security Incident Special Rules
If the incident involves possible secret exposure:
1) rotate affected secrets immediately
2) revoke suspect sessions/tokens
3) check access logs
4) escalate to SEV1 minimum (SEV0 if data breach confirmed)
5) **CSO takes lead on investigation**

**See also:** `standards/SECURITY_AND_ACCESS.md` §7

---

## 7) Postmortems (required for SEV0/SEV1; recommended for SEV2)

### 7.1 Ownership
- **CSO leads** the postmortem process
- **CTO owns** technical remediation action items
- **COO owns** process/operational action items

### 7.2 Postmortem timeline
- SEV0/SEV1: within 72 hours
- SEV2: within 7 days (recommended)

### 7.3 Postmortem rules
- no blame
- focus on systems and controls
- must produce action items with owners + deadlines

---

## 8) Postmortem Template (copy/paste)

### Incident Summary
- Severity:
- Start time:
- End time:
- Duration:
- Customer impact:
- Systems affected:

### Timeline (facts only)
- T0:
- T+:
- T+:

### Root Cause
- Direct cause:
- Contributing factors:

### Detection
- How was it detected?
- Why wasn't it detected earlier?

### Mitigation / Resolution
- What was done?
- Why it worked?

### What went well
-

### What went poorly
-

### Prevent Recurrence (Action Items)
| Action | Owner | Deadline | Status |
|---|---|---|---|
| | | | |

### Canon/SOP Updates
- Which SOPs/templates will be updated and how?

---

## 9) Action Item Tracking (non-negotiable)
- Every SEV0/SEV1 postmortem must create tracked tickets.
- Action items are reviewed weekly until closed.
- Repeated incidents of the same class trigger a standards update.
- **CSO tracks policy/standards updates; CTO tracks technical fixes.**

---

## 10) Required Artifacts
- incident timeline log
- severity level + roles assigned
- rollback/fix notes
- postmortem (if required)
- action items list

---

## 11) Changelog
- 2026-02-02 — v1.1 — Added CSO co-ownership, investigation/postmortem leadership, cross-references to charters
- 2026-02-02 — v1.0 — Initial incident + postmortem SOP
