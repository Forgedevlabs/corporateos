# QA Gate SOP — External Output Gating

**Owner:** Maxwell (COO) | **Primary Executor:** Vera (Content QA), Cypress (Code QA)  
**Last Updated:** 2026-02-04  
**Status:** ACTIVE  
**Supersedes:** None (complements `QA_CHECKLIST.md` and `VERIFICATION_PROTOCOL.md`)

---

## 0) Purpose

Nothing leaves this organization without a QA gate. This SOP defines **how QA gates external output** — what gets reviewed, the approval format, what blocks shipping, and how to escalate when things get stuck.

This is the enforcement mechanism behind Gate C (External Ship) from `WORKFLOW.md`.

---

## 1) Scope — What Gets Gated

### Always Gated (No Exceptions)
| Output Type | QA Reviewer | Gate |
|-------------|-------------|------|
| Published content (tweets, threads, newsletters, articles) | Vera | Gate C |
| Code deployed to production | Cypress | Gate C |
| Public-facing UI/design changes | Vera + Cypress | Gate C |
| External communications (press, partner emails, public statements) | Vera | Gate C |
| New tool/integration going live | Cypress + Sentinel | Gate B + C |

### Not Gated (Internal Only)
- Internal proposals (reviewed but not gated)
- Draft content not yet queued for publication
- Local dev/staging code changes
- Internal memos and working docs

**Rule of thumb:** If a human outside this organization will see it, it's gated.

---

## 2) Submission Process

### 2.1 How to Submit for QA

The producing executive (or worker) creates a QA submission by:

1. **Place the artifact** in the appropriate location (`06_PROPOSALS/`, working directory, etc.)
2. **Tag QA** with a clear request:
   ```
   QA REQUEST — [Vera/Cypress]
   Artifact: [file path or link]
   Type: [content/code/UI/external comms]
   Context: [one sentence — what this is and why it exists]
   Deadline: [when this needs to ship]
   ```
3. **Self-review first** — submitter must have checked against `QA_CHECKLIST.md` before submitting. If QA catches a checklist item the submitter should have caught, that's a process failure logged against the submitter.

### 2.2 What QA Needs to Review

QA does NOT re-do the work. QA verifies:

- **Content (Vera):** Checklist compliance per `QA_CHECKLIST.md`, voice alignment, factual accuracy, format compliance
- **Code (Cypress):** Tests pass, security scan, runs locally, documentation exists per `QA_CHECKLIST.md`
- **Both:** The artifact does what it claims. No placeholders. No dead links. Works end-to-end.

---

## 3) Approval Format

### PASS
```
## QA PASS — [Reviewer Name]
**Date:** YYYY-MM-DD
**Artifact:** [file/link]
**Verdict:** PASS — Ready to ship.
```
→ Artifact moves to CEO for final sign-off (Gate C completion).

### CONDITIONAL PASS
```
## QA CONDITIONAL PASS — [Reviewer Name]
**Date:** YYYY-MM-DD
**Artifact:** [file/link]
**Verdict:** CONDITIONAL PASS
**Conditions:** [specific minor issues that don't block shipping]
**Ship window:** Can ship now; fix [conditions] within 24h.
```
→ Artifact can ship. Conditions tracked as follow-up tasks.

### FAIL
```
## QA FAIL — [Reviewer Name]
**Date:** YYYY-MM-DD
**Artifact:** [file/link]
**Verdict:** FAIL
**Required Changes:**
1. [SPECIFIC]: [issue] → [fix needed]
2. [SPECIFIC]: [issue] → [fix needed]
**Resubmit by:** [deadline]
```
→ Artifact returns to producer. See `QA_CHECKLIST.md` for full rejection format.

---

## 4) What Blocks Shipping (Hard Stops)

These are **automatic FAIL, no exceptions:**

| Blocker | Why |
|---------|-----|
| Factual error in published content | Destroys credibility |
| Hardcoded secret in code | Security breach risk |
| Tests failing | Broken deployment |
| Placeholder content ("Lorem ipsum", "TODO") | Unprofessional |
| Missing required checklist items (>2) | Incomplete work |
| Security vulnerability (high/critical) | Liability |
| No evidence of local testing (code) | Unverified |

These are **warnings** (may block at reviewer discretion):
- Minor typos (1-2)
- Suboptimal but functional code
- Voice slightly off but not wrong
- Missing optional metadata

---

## 5) Retry Policy

| Attempt | Action |
|---------|--------|
| 1st submission | Normal QA review |
| 1st FAIL | Producer fixes, resubmits |
| 2nd FAIL | Producer fixes, QA reviews with extra scrutiny |
| 3rd FAIL | **Escalation triggered** — QA escalates to CEO |

**Max retries: 3.** After 3 FAILs on the same artifact, the task is escalated to Alfred (CEO) for resolution — reassignment, scope change, or cancellation.

---

## 6) SLA — QA Turnaround Times

| Priority | Turnaround |
|----------|-----------|
| P0 (shipping today) | Within 1 hour |
| P1 (shipping this shift) | Within 2 hours |
| P2 (shipping this cycle) | Within 4 hours |
| P3 (queued, no rush) | Within 24 hours |

**If QA is blocked** (overloaded, ambiguous requirements), QA must communicate the delay within 30 minutes of receiving the request.

---

## 7) Escalation Paths

### QA → CEO (Standard Escalation)
**When:** 3+ FAILs, disagreement on standards, blocking ambiguity  
**Format:** Use the Escalation Format from `QA_CHECKLIST.md`  
**Response expected:** Within 1 hour for P0/P1, within 4 hours for P2/P3

### QA → CSO (Security Escalation)
**When:** Security vulnerability discovered during review  
**Action:** Immediate flag to Sentinel (CSO). Do NOT ship. See `SECURITY_AND_ACCESS.md` §7  
**Response expected:** Immediate for confirmed vulnerabilities

### QA → COO (Process Escalation)
**When:** Repeated process failures (submitters not self-reviewing, missing context, SOP not followed)  
**Action:** Maxwell logs the pattern, updates SOPs or training as needed  
**Response expected:** Within 24 hours (process improvement, not urgent fix)

### Producer → CEO (QA Dispute)
**When:** Producer disagrees with QA FAIL decision  
**Action:** Producer presents case to Alfred with artifact + QA feedback  
**Rule:** QA decision stands until CEO overrides. No shipping during dispute.

---

## 8) Audit Trail

All QA decisions are logged at: `~/.openclaw/corporate_os/05_LOGS/qa_log.md`

Format:
```
| Date | Artifact | Reviewer | Decision | Attempt | Notes |
|------|----------|----------|----------|---------|-------|
```

QA log is reviewed weekly during Ops Review (see `SCOREBOARDS_AND_WEEKLY_OPS_REVIEW.md`).

---

## 9) Cross-References

| Document | Relevance |
|----------|-----------|
| `03_SOPS/QA_CHECKLIST.md` | Specific pass/fail criteria and checklists |
| `03_SOPS/VERIFICATION_PROTOCOL.md` | Two-stage verification (proposal + implementation) |
| `WORKFLOW.md` | Gate C definition, chain of command |
| `03_SOPS/SECURITY_AND_ACCESS.md` | Security gate (Gate B) |
| `00_GOVERNANCE/OPERATING_PACK_v1.md` | Gate definitions (A/B/C) |
| `03_SOPS/CODING_PIPELINE_SOP.md` | Code-specific pipeline with QA stage |

---

*This SOP is enforced immediately. All external output must pass through this gate starting 2026-02-04.*
