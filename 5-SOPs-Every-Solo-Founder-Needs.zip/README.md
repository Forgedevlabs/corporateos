# 5 SOPs Every Solo Founder Needs
## From CorporateOS by The Forge

These 5 SOPs were extracted from CorporateOS — a complete AI-native operating system built through 6 months of daily production use.

Each SOP exists because something broke without it.

---

## What's Included

1. **DAILY_CADENCE.md** — Your daily rhythm. What happens when, and why.
2. **WORK_INTAKE_AND_PRIORITIZATION.md** — Decide what gets done. Stop drowning in tasks.
3. **INCIDENT_RESPONSE_POSTMORTEM.md** — When things break, here's your playbook.
4. **EXEC_COMMS_AND_DECISION_LOG.md** — Stop re-debating decisions you already made.
5. **QA_GATE_SOP.md** — Define "done" before you ship. Speed without quality is fast failure.

---

## How to Use

1. **Pick ONE SOP** that addresses your biggest current pain
2. Read it. Adapt the template to your context. Start using it today.
3. Add a second SOP next week. Don't try to implement all 5 at once.

These are markdown files. They work with any text editor, Obsidian, VS Code, or AI agent context. If you use AI agents (Claude, GPT, Cursor), drop them in your project and your agent will follow the process.

---

## Want the Complete System?

CorporateOS includes **96 files**: 29 SOPs, governance framework, finance system, security framework, brand standards, 14 executive role charters, and templates for everything.

Everything interconnects. The daily cadence references the work intake SOP. The work intake SOP references the QA gate. The QA gate references the deployment SOP. It's a system, not a collection.

**$49. One purchase. Yours forever.**

→ Get CorporateOS: https://theforge.sh/corporateos

---

Built by The Forge · [theforge.sh](https://theforge.sh)
