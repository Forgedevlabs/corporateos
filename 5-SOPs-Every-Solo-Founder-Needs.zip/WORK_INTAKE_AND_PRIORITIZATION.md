# WORK_INTAKE_AND_PRIORITIZATION_SOP.md
**Owner:** COO  
**Enforced by:** COO + Department Heads  
**Applies to:** All work requests and initiatives across the organization and its portfolio  
**Status:** Non-Negotiable (controls what gets worked on and in what order)

> **Cross-references:**
> - `executives/COO_CHARTER.md` — COO authority
> - `executives/CTO_CHARTER.md` — Technical routing (§5.3)
> - `executives/CSO_CHARTER.md` — Security routing (§5.4)
> - `executives/CFO_CHARTER.md` — Financial routing (§5.5)
> - `executives/EIC_CHARTER.md` — Content routing (§5.6)
> - `standards/OPERATIONS_SYSTEM.md` — Operating system spine

---

## 0) Purpose
This SOP prevents:
- random work
- priority chaos
- "busy" without results
- invisible backlogs

It defines:
- how work enters the organization
- how it gets approved
- how it gets prioritized
- how it gets routed to the right executive (CTO/EIC/etc.)

---

## 1) Work Intake (required format)

No request is accepted unless it includes the **Intake Minimums**:

### Intake Minimums
- **Owner:** one accountable person
- **Venture:** [specify venture or holding company]
- **Objective:** what outcome we want
- **Metric:** how we'll know it worked
- **Deadline:** date + time
- **Scope:** what is included / excluded
- **Dependencies:** people/systems required
- **Risk level:** low / med / high
- **Approval needs:** CTO? CSO? CFO? EIC? QA? Legal? (if applicable)

If any field is missing → **returned to sender**.

---

## 2) Work Categories (how we classify requests)

Every item must be categorized:

1) **Revenue-Critical**
   - direct lead gen, sales, conversion, billing, offer delivery

2) **Product-Critical**
   - core product functionality, onboarding, retention loops

3) **Trust-Critical**
   - security, reliability, data integrity, publishing standards

4) **Ops-Critical**
   - SOP creation, automation, hiring/onboarding, reporting

5) **Nice-to-Have**
   - improvements without clear metric impact

Default rule:
- Trust-Critical > Revenue-Critical > Product-Critical > Ops-Critical > Nice-to-Have

(CEO can override intentionally, but never accidentally.)

---

## 3) Prioritization Scoring (simple and ruthless)

COO assigns a score using 4 numbers (1–5).

### 3.1 Scoring fields
- **Impact (I):** how much it moves the metric
- **Urgency (U):** how time-sensitive it is
- **Effort (E):** how hard it is (higher = harder)
- **Risk (R):** how risky it is to delay (higher = more risk)

### 3.2 Priority Score (formula)
**Score = (I + U + R) – E**

Higher score = higher priority.

### 3.3 Tie-breakers
If two items have equal score, choose:
1) lower effort
2) higher trust risk
3) faster feedback loop (learn sooner)

---

## 4) WIP Limits (work-in-progress caps)

The organization cannot run 10 priorities at once.

### Standard WIP limits
Per venture:
- **Max 2 active initiatives**
- **Max 5 active projects**
- **Max 10 active tasks per team**

High-risk items:
- **Max 2 concurrent high-risk items** (per venture)

If WIP is full → new work is queued, not started.

---

## 5) Approval Rules (who must sign off)

### 5.1 CEO approval required
- new venture spawn
- major strategy shift
- major pricing/offer changes
- major resource allocation changes

### 5.2 COO approval required
- anything entering execution
- any work that changes cadence, SOPs, or routing
- hiring/onboarding process changes

### 5.3 CTO approval required (route when triggered)
Route to CTO when work involves:
- auth, permissions, payments, PII
- architecture decisions
- infra changes
- production integrations
- security implementation

### 5.4 CSO approval required (route when triggered)
Route to CSO when work involves:
- security policy decisions
- privacy/compliance requirements
- vendor data access
- access control policy changes
- risk assessment needed

### 5.5 CFO approval required (route when triggered)
Route to CFO when work involves:
- any spend commitment
- budget allocation
- vendor contracts
- revenue model changes
- cost structure changes

### 5.6 EIC approval required (route when triggered)
Route to EIC when work is public-facing and includes:
- new brand/offer positioning
- comparative claims, risky claims
- flagship pages and paid distribution copy
- tone/voice changes

### 5.7 Creative Director approval required (route when triggered)
Route to CD when work involves:
- new venture brand identity
- visual identity changes (logo, color, typography)
- landing pages, pricing pages, homepage redesigns
- paid media campaign creatives
- UI modules or major UI overhauls
- flagship visual assets

### 5.8 QA/Audit review required
Route to QA/Audit when:
- claims need proof notes
- security policy may be affected
- high-trust public content is shipping

---

## 6) Routing Decision Tree (quick)

1) **Is it public-facing messaging?** → EIC trigger check
2) **Is it visual/brand/design work?** → CD trigger check
3) **Does it touch auth/PII/payments/infra?** → CTO trigger check
4) **Does it involve security policy or privacy?** → CSO trigger check
5) **Does it involve spend or contracts?** → CFO trigger check
6) **Is it recurring work?** → requires SOP creation or SOP update
7) **Is it revenue-critical within 14 days?** → fast-track scoring
8) **Otherwise** → normal scoring + queue

---

## 7) Fast-Track Lane (urgent, high leverage)

Fast-track is allowed only when:
- urgent revenue-critical issue, or
- trust-critical incident, or
- blocking launch

Fast-track rules:
- still requires owner + metric + deadline
- still routes to CTO/CSO/CFO/EIC when triggered
- must be reviewed in the next Weekly Ops Review

---

## 8) Definition of "Done" (acceptance criteria)

No item is done unless:
- acceptance criteria are met
- metric tracking is live (if applicable)
- documentation updated (SOP or decision log, if needed)

"Built" is not done. "Verified + tracked" is done.

---

## 9) Required Artifacts
- Intake form (filled)
- Priority score
- Owner + deadline
- Routing approvals logged (if triggered)
- Acceptance criteria

---

## 10) Exceptions

Exceptions require:
- COO approval
- written reason
- logged in the decision log

No silent exceptions.

---

## 11) Changelog
- 2026-02-02 — v1.1 — Added CSO routing (§5.4), CFO routing (§5.5), cross-references, made generic
- 2026-02-02 — v1.0 — Initial work intake and prioritization SOP
