# SOP: Daily Operating Cadence
**Owner:** Maxwell (COO)
**Enforced by:** Harper (CoS) + Alfred (CEO)
**Applies to:** All CorporateOS executives
**Status:** Non-Negotiable (ratified via COO DailyCadence proposal, 2026-02-01)
**Last Updated:** 2026-02-04

---

## 0) Purpose

Keep the organization moving with consistent daily updates and consolidation. No exec operates in a vacuum. No blocker goes undetected for more than 24 hours.

---

## 1) Daily Update (Each Exec → Their Lane)

Each executive posts this template in their Telegram topic:

```
[DAILY UPDATE] <ROLE> — <YYYY-MM-DD>
Done:
Next:
Blockers:
Decisions needed:
Risks spotted:
Links (proposal/task paths):
```

**Timing:** Before 10:00 AM local (America/New_York)

**Who:**
| Role | Lane |
|------|------|
| CTO (Victor) | CTO Lane |
| COO (Maxwell) | COO Lane |
| CFO (Sterling) | CFO Lane |
| CMO (Sage) | CMO Lane |
| CSO (Sentinel) | CSO Lane |

**Update Rules:**
- "Done" must reference specific task IDs or file paths
- "Blockers" must include who can unblock
- "Decisions needed" must be actionable yes/no questions where possible
- No empty fields — write "None" if nothing to report

---

## 2) Daily Consolidation (CoS → CEO-INBOX)

**Owner:** Harper (CoS)
**Deadline:** Before 11:00 AM local (1 hour after exec deadline)
**Destination:** CEO-INBOX topic

```
[CoS CONSOLIDATION] <YYYY-MM-DD>
P0 Progress:
Blockers:
Decisions queued:
QA status:
Owner attention needed (yes/no):
```

**Rules:**
- Aggregate all 5 exec updates into single summary
- Highlight cross-functional blockers
- Queue decisions that need CEO or Owner action
- Include QA gate status from Vera
- Flag if Owner attention is truly needed (don't cry wolf)

---

## 3) Weekly Board Report (CEO → CONTROL ROOM)

**Owner:** Alfred (CEO)
**Deadline:** Sunday by 6:00 PM local
**Destination:** CONTROL ROOM topic
**Template:** `08_REPORTS/_TEMPLATE_WEEKLY.md`

**Contents:**
- Wins (needle-movers only, not busywork)
- KPI Snapshot
- Current Priorities (P0)
- Decisions needed from Owner
- Risks
- Next week plan

**Cadence relationship:**
```
Mon-Sat: Daily exec updates → CoS consolidation
Sunday:  Weekly CEO report → Owner review
```

---

## 4) Failure Modes & Escalation

| Failure | Detection | Escalation | Deadline |
|---------|-----------|------------|----------|
| Exec misses daily update | CoS checks lanes by 10:30 AM | CoS → direct ping to exec | 2 hours to respond |
| 2+ consecutive misses | CoS tracks in HEARTBEAT.md | CoS → escalate to CEO | Same day |
| CoS consolidation late | CEO checks CEO-INBOX by 11:30 AM | CEO checks lanes directly | Notes in HEARTBEAT |
| Weekly report missed | Owner checks CONTROL ROOM Sunday night | CoS takes over report, escalates to Owner | Monday 9 AM |

**Escalation principles:**
1. First miss = direct ping, no drama
2. Second miss = CEO visibility
3. Third miss = Owner visibility + process review
4. Never let silence cascade — someone must own detection

---

## 5) Heartbeat Maintenance

Harper (CoS) maintains `HEARTBEAT.md`:
- Detect overdue tasks
- Reassign if stalled
- Ping lanes for updates
- Queue decisions and QA checks
- Update frequency: at least daily

---

## Quality Checklist
- [ ] All 5 execs posted daily updates before 10 AM
- [ ] CoS consolidation posted before 11 AM
- [ ] No tasks overdue >24h without blocker noted
- [ ] Weekly report posted by Sunday 6 PM
- [ ] All "done" items reference specific deliverables
- [ ] No empty files marked as complete

---

## Cross-References
- `06_PROPOSALS/2026-01-31_COO_DailyCadence.md` — Ratified proposal (source of truth for this SOP)
- `03_SOPS/VERIFICATION_PROTOCOL.md` — How "done" gets verified

---

*The cadence is the heartbeat of CorporateOS. If it stops, everything stops.*
