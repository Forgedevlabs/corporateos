# EXEC_COMMS_AND_DECISION_LOG.md
**Owner:** Chief of Staff (CoS)
**Enforced by:** CoS + COO (workflow)
**Applies to:** All executive decisions, meetings, and strategic communications
**Status:** Non-Negotiable (prevents drift, confusion, and repeated mistakes)

---

## 0) Purpose

This SOP solves:
- the CEO working "off-system"
- repeated mistakes and contradictions
- unclear decisions and missing owners
- meetings that create no outcomes

It defines:
- how executives communicate decisions
- how decisions become tasks
- how decisions are logged and revisited
- how action items are tracked to completion

---

## 1) The Decision Standard (required format)

Any executive decision must be captured in a single entry with:

**Decision Entry Fields**
- Decision (one sentence)
- Why (reason)
- Tradeoffs (what we give up)
- Owner (single accountable person)
- Deadline (date/time)
- Success metric (how we know it worked)
- Dependencies (if any)
- Risks (top 1–3)
- Revisit conditions (what would make us change this)
- Date + approver

If any field is missing → the decision is not valid.

**Template:** `~/.openclaw/corporate_os/02_DECISIONS/DECISION_TEMPLATE.md`

---

## 2) Decision Log Types

### 2.1 Strategic decisions
- portfolio direction
- venture prioritization
- resource allocation
- major partnerships

### 2.2 Operating decisions
- cadence changes
- SOP changes
- routing rule changes

### 2.3 High-risk decisions
- security/privacy
- brand/claims
- production architecture
- legal exposure

High-risk decisions require the appropriate executive signoff:
- CTO for security/architecture
- EIC for claims/tone/public messaging
- COO for operations/cadence

---

## 3) CEO Communication Rules (to prevent mistakes)

### 3.1 CEO cannot "assign in conversation"

Conversation is not an assignment. Assignments must be written in the standard format:
- Owner
- Deadline
- Acceptance criteria
- Metric (if applicable)

### 3.2 The CEO Focus Filter

CEO should only do:
- decisions only the CEO can make
- relationships only the CEO can build
- approvals where required
- high-leverage direction setting

Everything else must be delegated.

### 3.3 The "Return to Sender" rule

If the CEO sends a request without intake minimums, CoS returns it with:
- "Needs owner, metric, deadline, acceptance criteria."

---

## 4) Meeting System (executive communications)

### 4.1 Every meeting must have
- agenda
- desired outcomes
- pre-read (if complex)
- time box
- action items at the end

### 4.2 Meeting outputs (mandatory)

After any executive meeting, CoS publishes:
- decisions made (in decision entry format)
- action items (owner, deadline)
- open questions (who answers, by when)

No outputs → meeting doesn't count.

---

## 5) Action Item Tracking (non-negotiable)

### 5.1 Action item fields
- task
- owner
- due date
- status (not started/in progress/blocked/done)
- blocker (if any)
- linked decision (if applicable)

### 5.2 Weekly enforcement

Every Weekly Ops Review must include:
- review of overdue actions
- blocker resolution
- re-assignment or scope reduction if needed

---

## 6) Escalation Rules (who gets pulled in)

Escalate immediately when:
- a task is blocked > 48 hours
- a deadline slips twice
- the work touches trust-critical areas

Route to:
- CTO for security/architecture
- EIC for public messaging/claims
- COO for ops bottlenecks
- CEO for strategic conflict

**Full routing table:** `~/.openclaw/corporate_os/00_GOVERNANCE/ROUTING_MAP.md`

---

## 7) Revisit and Debrief (prevents repeating mistakes)

### Weekly "Revisit" slot (10 min)

CoS selects 1–3 decisions to revisit if:
- metrics contradict assumptions
- conditions changed
- new risks appeared

### Monthly "CEO Mistake Review" (15–30 min)

Not blame — system improvement:
- identify repeated failure modes
- create prevention mechanisms (SOP, delegation, checklists)

---

## 8) Cross-References

- **CoS Charter:** `~/.openclaw/corporate_os/executives/COS_CHARTER.md` — Harper's authority to enforce this SOP
- **Decision Log:** `~/.openclaw/corporate_os/02_DECISIONS/` — where decisions are stored
- **Decision Template:** `02_DECISIONS/DECISION_TEMPLATE.md` — required format
- **Routing Map:** `00_GOVERNANCE/ROUTING_MAP.md` — escalation routing

---

## 9) Exceptions

Exceptions require CEO + CoS approval and must be logged.

---

## 10) Changelog
- 2026-02-04 — v1.0 — Initial placement in CorporateOS (adapted from Fortis source)
